package Week2Day2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class WindowsHandle  {
    public static void main(String[] args) throws InterruptedException {
        EdgeDriver driver = new EdgeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.irctc.co.in/");
        Thread.sleep(1000);
        driver.findElement(By.xpath("//a[text()=' FLIGHTS ']")).click();
        Set<String> setrail = driver.getWindowHandles();
        System.out.println(setrail);
        Thread.sleep(1000);
        List<String> listrail = new ArrayList<String>(setrail);
        // Thread.sleep(2000);
       driver.switchTo().window(listrail.get(1));
       driver.getTitle();
       System.out.println("The title of the new window is" + driver.getTitle());
       Thread.sleep(1000);
        driver.switchTo().window(listrail.get(0));
        String parentaddress = listrail.get(0);
        System.out.println("The Address of Train ticket booking is" + parentaddress);

       driver.close();
    }
}
