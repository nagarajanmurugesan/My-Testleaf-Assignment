package week2Day1;

public class ConcreteClassAmazon extends CanaraBank{



    public void recordPaymentDetails() {
        System.out.println("Record Payment details updated");

    }
    public void cashOnDelivery() {
        System.out.println("Cash on Delivery Updated");
    }


    public void internetBanking() {
        System.out.println("Internet Banking Updated");

    }
    public void upiPayments() {
        System.out.println("Upi Payments Updated");
    }
    public void cardPayments() {
        System.out.println("Card Payments Updated");
    }


    public static void main(String[] args) {
        ConcreteClassAmazon follow = new ConcreteClassAmazon();
        follow.cashOnDelivery();
        follow.recordPaymentDetails();
        follow.cardPayments();
        follow.upiPayments();
        follow.internetBanking();
    }
}
