package week2Day1;

import org.apache.xmlbeans.impl.xb.xsdschema.Public;
import org.openqa.selenium.chrome.ChromeDriver;

public abstract class CanaraBank implements Payments {
    public abstract void recordPaymentDetails();

}
