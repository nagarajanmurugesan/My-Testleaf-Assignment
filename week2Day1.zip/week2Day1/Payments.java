package week2Day1;

public interface Payments {
    public void cashOnDelivery ();
    public void upiPayments ();
    public void cardPayments ();
    public void internetBanking();
}
