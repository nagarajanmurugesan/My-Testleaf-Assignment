package week1.day2;

public class FindOddNumbers {
    public static void main(String[] args) {
        for (int i = 1; i <=10 ; i++) {
            if (i%2==0) {
                continue;
            }

            else
            {
                System.out.println(i);
            }
        }

    }
}

//package week1.day2;
//public class FindOddNumbers {
// public static void main(String[] args) {
//   for (int i = 1; i <= 10; i++) {
//  if (i % 2 == 1) {
//     System.out.println(i);
//  }
//  }
//}



///package week1.day2

//public class FindOddNumbers {
///public static void main(String[] args) {
//for (int i = 1; i <=10 ; i++) {
// if (i%2 !=0) {
//System.out.println(i);
//      }



//   }
// }

// }
//}
